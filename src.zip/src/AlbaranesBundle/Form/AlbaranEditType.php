<?php

namespace AlbaranesBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;


use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;
use Symfony\Component\Form\Extension\Core\Type\DateType;

class AlbaranEditType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('fecha', DateType::class, array(
                        'label' => 'Fecha',
                        'attr' => array("onchange" => "javascript:marcaCambio();"),
                        'required'  => true,
                        'widget' => 'single_text'))
                ->add('cliente')
//                ->add('concepto')
//                ->add('total', MoneyType::class,array('label' => 'Total',
//                        'scale' => 2,
//                        'grouping' => true,
//                        'required'  => false,
//                        'attr'  => array(
//                            'data-thousands' =>'.',
//                            'data-decimal' =>',',
//                            "onchange" => "javascript:marcaCambio();")
//                    ))
                ->add('iVA',NumberType::class,array('label' => '% IVA',
                        'required'  => false,
                        'attr'  => array("onchange" => "javascript:marcaCambio();")
                    ))
                ->add('tipoPago')
                ->add('trabajador');
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AlbaranesBundle\Entity\Albaran'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'albaranesbundle_albaran';
    }


}
