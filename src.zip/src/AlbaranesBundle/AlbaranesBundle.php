<?php

namespace AlbaranesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AlbaranesBundle extends Bundle
{
}
