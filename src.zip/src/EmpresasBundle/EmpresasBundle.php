<?php

namespace EmpresasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EmpresasBundle extends Bundle
{
}
