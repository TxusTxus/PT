<?php

namespace ComunicacionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ComunicacionBundle extends Bundle
{
}
