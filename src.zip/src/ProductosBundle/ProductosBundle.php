<?php

namespace ProductosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductosBundle extends Bundle
{
}
