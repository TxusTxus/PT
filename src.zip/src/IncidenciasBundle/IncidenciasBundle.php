<?php

namespace IncidenciasBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IncidenciasBundle extends Bundle
{
}
