<?php

namespace UsuariosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UsuariosBundle extends Bundle
{
}
