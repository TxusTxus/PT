<?php

namespace ClientesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ClientesBundle extends Bundle
{
}
