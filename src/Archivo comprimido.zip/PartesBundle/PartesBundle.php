<?php

namespace PartesBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PartesBundle extends Bundle
{
}
