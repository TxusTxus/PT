<?php

namespace TrabajadoresBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TrabajadoresBundle extends Bundle
{
}
